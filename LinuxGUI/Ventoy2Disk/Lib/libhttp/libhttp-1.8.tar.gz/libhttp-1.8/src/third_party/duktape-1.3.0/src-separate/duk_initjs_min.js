(function(d,a){function b(a,b,c){Object.defineProperty(a,b,{value:c,writable:!0,enumerable:!1,configurable:!0})}b(a.Logger,"clog",new a.Logger("C"));b(a,"modLoaded",{})})(this,Duktape);
